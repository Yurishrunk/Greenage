package com.example.mirandaabel01;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class PlantSrcn extends AppCompatActivity {

    FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.plantscrn);

        firestore = FirebaseFirestore.getInstance();

        Button exitButton = findViewById(R.id.exit);
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PlantSrcn.this, Activity2.class);
                startActivity(intent);
                finish();
            }
        });

        Button aloe = findViewById(R.id.btn1);
        aloe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firestore.collection("Plants").document("Aloevera")
                        .get()
                        .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                            @Override
                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                String details = documentSnapshot.getString("details");

                                Intent intent = new Intent(PlantSrcn.this, PlantDetails.class);
                                intent.putExtra("plantDetail", details);
                                startActivity(intent);
                                finish();
                            }
                        });
            }
        });
        Button lagundi = findViewById(R.id.btn2);
        lagundi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firestore.collection("Plants").document("Lagundi")
                        .get()
                        .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                            @Override
                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                String details = documentSnapshot.getString("details");

                                Intent intent = new Intent(PlantSrcn.this, PlantDetails.class);
                                intent.putExtra("plantDetail", details);
                                startActivity(intent);
                                finish();
                            }
                        });
            }
        });
        Button kalabasa = findViewById(R.id.btn3);
        kalabasa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firestore.collection("Plants").document("Kalabasa")
                        .get()
                        .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                            @Override
                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                String details = documentSnapshot.getString("details");

                                Intent intent = new Intent(PlantSrcn.this, PlantDetails.class);
                                intent.putExtra("plantDetail", details);
                                startActivity(intent);
                                finish();
                            }
                        });
            }
        });
        Button ampalaya = findViewById(R.id.btn4);
        ampalaya.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firestore.collection("Plants").document("Ampalaya")
                        .get()
                        .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                            @Override
                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                String details = documentSnapshot.getString("details");

                                Intent intent = new Intent(PlantSrcn.this, PlantDetails.class);
                                intent.putExtra("plantDetail", details);
                                startActivity(intent);
                                finish();
                            }
                        });
            }
        });
        Button sitaw = findViewById(R.id.btn5);
        sitaw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firestore.collection("Plants").document("Sitaw")
                        .get()
                        .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                            @Override
                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                String details = documentSnapshot.getString("details");

                                Intent intent = new Intent(PlantSrcn.this, PlantDetails.class);
                                intent.putExtra("plantDetail", details);
                                startActivity(intent);
                                finish();
                            }
                        });
            }
        });
    }
}
