package com.example.mirandaabel01;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.content.Intent;
import androidx.annotation.NonNull;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.core.view.GravityCompat;
import com.google.android.material.navigation.NavigationView;

import androidx.appcompat.app.AppCompatActivity;

public class Activity2 extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private ImageButton leafMenuButton;
    private NavigationView navigationView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inscrn);

        drawerLayout = findViewById(R.id.drawer);
        leafMenuButton = findViewById(R.id.leafmenu);
        navigationView = findViewById(R.id.menu);

        leafMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();

                if (id == R.id.Plant) {
                    Toast.makeText(Activity2.this, "Your now on Plant section", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Activity2.this, PlantSrcn.class);
                    startActivity(intent);
                    drawerLayout.closeDrawer(GravityCompat.START);
                    return true;
                }
                else if (id == R.id.Tips) {
                    Toast.makeText(Activity2.this, "Your now on Tips section", Toast.LENGTH_SHORT).show();
                    Intent tipsIntent = new Intent(Activity2.this, Tipsrcn.class);
                    startActivity(tipsIntent);
                    drawerLayout.closeDrawer(GravityCompat.START);
                    return true;
                }
                else if (id == R.id.About) {
                    Toast.makeText(Activity2.this, "Your now on About us section", Toast.LENGTH_SHORT).show();
                    Intent tipsIntent = new Intent(Activity2.this, Abtsrcn.class);
                    startActivity(tipsIntent);
                    drawerLayout.closeDrawer(GravityCompat.START);
                    return true;
                }
                return false;
            }
        });

    }
}


